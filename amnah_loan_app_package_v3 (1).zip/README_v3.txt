Amnah Payday Loan — v3 package contents and next steps

Files added in v3:
- mockups/*.png  (7 high-fidelity screens: splash, login, signup, home, loanform, calculator, admin)
- code/AdminUtils.kt  (Admin role check helper using Firestore)
- code/AppNavHost_AdminCheck.md  (instructions & snippet)
- tests/LoanCalculatorTest.kt  (JUnit tests for LoanCalculator)
- signing/  (instructions below)

Unit tests:
- Place LoanCalculatorTest.kt under app/src/test/java/com/amnah/payday/utils/
- Run tests in Android Studio: Run -> Run 'All Tests' or via Gradle:
  ./gradlew test

APK Build Guide:

A) Debug APK (easy install)
1. In Android Studio: Build -> Build Bundle(s) / APK(s) -> Build APK(s)
   This produces an unsigned debug APK located at app/build/outputs/apk/debug/app-debug.apk
2. Install on device:
   adb install -r app/build/outputs/apk/debug/app-debug.apk

B) Signed Release APK (ready for Play Store)
1. Create a keystore:
   keytool -genkey -v -keystore amnah_keystore.jks -alias amnah_key -keyalg RSA -keysize 2048 -validity 10000
   Move keystore to app/keystore/amnah_keystore.jks
2. Add signing config to app/build.gradle (example):
   signingConfigs {
       release {
           keyAlias 'amnah_key'
           keyPassword 'REPLACE_WITH_PASSWORD'
           storeFile file('keystore/amnah_keystore.jks')
           storePassword 'REPLACE_WITH_PASSWORD'
       }
   }
   buildTypes {
       release {
           signingConfig signingConfigs.release
           minifyEnabled false
       }
   }
3. Build release:
   ./gradlew assembleRelease
   Output at app/build/outputs/apk/release/app-release.apk
4. Verify and align (optional if using Android Studio it's handled). Use jarsigner/zipalign if needed.

Notes:
- I cannot run Gradle or Android SDK commands in this environment, so I provide exact commands and files you can run locally.
- If you want, I can give a step-by-step terminal session tailored to your OS (Linux/Windows/macOS).

Admin role checks:
- AdminUtils.kt contains a suspend function isCurrentUserAdmin() — call it before navigating to admin routes.
- For UI, show/hide admin entry points based on this check.

Next actions I can do now:
- Generate unit test coverage reports (if you run tests locally I can help interpret results).
- Create CI script (GitHub Actions) to run tests and build debug APK on push (I can add the workflow file).

