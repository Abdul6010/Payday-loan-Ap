package com.amnah.payday.utils

import org.junit.Assert.assertEquals
import org.junit.Test
import kotlin.math.round

class LoanCalculatorTest {

    @Test
    fun test_zero_interest() {
        val principal = 120000.0
        val rate = 0.0
        val months = 12
        val monthly = LoanCalculator.calculateMonthlyPayment(principal, rate, months)
        assertEquals(10000.0, monthly, 0.001)
    }

    @Test
    fun test_nonzero_interest() {
        val principal = 50000.0
        val rate = 12.0 // annual
        val months = 6
        val monthly = LoanCalculator.calculateMonthlyPayment(principal, rate, months)
        // Compute expected using formula for verification
        val r = rate / 100.0 / 12.0
        val n = months.toDouble()
        val expected = (r * principal * Math.pow(1 + r, n)) / (Math.pow(1 + r, n) - 1)
        assertEquals(expected, monthly, 0.001)
    }

    @Test
    fun test_rounding_behavior() {
        val principal = 12345.0
        val rate = 10.0
        val months = 7
        val monthly = LoanCalculator.calculateMonthlyPayment(principal, rate, months)
        // Ensure monthly is positive and reasonable
        assert(monthly > 0)
    }
}
