/* AppNavHost snippet: when navigating to 'admin', ensure you check AdminUtils.isCurrentUserAdmin()
   Example usage in a Composable scope with coroutine:
   LaunchedEffect(Unit) {
       if (AdminUtils.isCurrentUserAdmin()) nav.navigate("admin")
       else scaffoldState.snackbarHostState.showSnackbar("Access denied")
   }
*/
